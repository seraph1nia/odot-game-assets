Ledger native UI runtime payload

Extract UI/ into your Godot project at res://UI/. Import with Godot before loading.
Read api.md for data/signals, modal hosting, engine coverage and integration limits.
No prototypes, game services, caches or authoring tools are included.
Game migration remains separately authorized.
